def run_code(requestBody):
    from flask import Flask, jsonify
    from tensorflow import keras
    import tensorflow as tf
    import numpy as np
    import io
    import base64
    import tensorflow_probability as tfp
    from upload_image_to_drive import upload_image_to_drive
    # Set data type
    DTYPE='float32'
    tf.keras.backend.set_floatx(DTYPE)
    response_data = {'training_data':{},'spicy_optimizer':{},'eikonal_solver':{},'eikonal_identification':{},'solution_of_burgers':{}}
    print("Received POST Request")
    # Set constants
    pi = tf.constant(np.pi, dtype=DTYPE)
    userViscosity = requestBody.get('viscosity')
    response_data['viscosity'] = userViscosity
    viscosity = userViscosity/pi

    def negative_sin(x):
        return -tf.sin(x)

    def negative_cos(x):
        return -tf.cos(x)

    def negative_tan(x):
        return -tf.tan(x)

    FUNCTIONS = {
    'sin': tf.sin,
    'cos': tf.cos,
    'tan': tf.tan,
    '-sin': negative_sin,
    '-cos': negative_cos,
    '-tan': negative_tan,
    }
    # Define initial condition
    def fun_u_0(x):
        func = FUNCTIONS.get(requestBody.get('function'))
        if func is None:
            raise ValueError(f"Invalid function name '{func_name}'")
        # return func(pi * x)
        return (tf.sin(pi * x))

    # Define boundary condition
    def fun_u_b(t, x):
        n = x.shape[0]
        return tf.zeros((n,1), dtype=DTYPE)

    # Define residual of the PDE
    def fun_r(t, x, u, u_t, u_x, u_xx):
        return u_t + u * u_x - viscosity * u_xx

    #Second Cell
    # Set number of data points
    N_0 = 50
    N_b = 50
    N_r = 10000

    # Set boundary
    tmin = requestBody.get('tmin')
    tmax = requestBody.get('tmax')
    xmin = requestBody.get('xmin')
    xmax = requestBody.get('xmax')

    # Lower bounds
    lb = tf.constant([tmin, xmin], dtype=DTYPE)
    # Upper bounds
    ub = tf.constant([tmax, xmax], dtype=DTYPE)

    # Set random seed for reproducible results
    tf.random.set_seed(0)

    # Draw uniform sample points for initial boundary data
    t_0 = tf.ones((N_0,1), dtype=DTYPE)*lb[0]
    x_0 = tf.random.uniform((N_0,1), lb[1], ub[1], dtype=DTYPE)
    X_0 = tf.concat([t_0, x_0], axis=1)

    # Evaluate intitial condition at x_0
    u_0 = fun_u_0(x_0)

    # Boundary data
    t_b = tf.random.uniform((N_b,1), lb[0], ub[0], dtype=DTYPE)
    x_b = lb[1] + (ub[1] - lb[1]) * tf.keras.backend.random_bernoulli((N_b,1), 0.5, dtype=DTYPE)
    X_b = tf.concat([t_b, x_b], axis=1)

    # Evaluate boundary condition at (t_b,x_b)
    u_b = fun_u_b(t_b, x_b)

    # Draw uniformly sampled collocation points
    t_r = tf.random.uniform((N_r,1), lb[0], ub[0], dtype=DTYPE)
    x_r = tf.random.uniform((N_r,1), lb[1], ub[1], dtype=DTYPE)
    X_r = tf.concat([t_r, x_r], axis=1)

    # Collect boundary and inital data in lists
    X_data = [X_0, X_b]
    u_data = [u_0, u_b]

    # Third Cell
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(9,6))
    plt.scatter(t_0, x_0, c=u_0, marker='X', vmin=-1, vmax=1)
    plt.scatter(t_b, x_b, c=u_b, marker='X', vmin=-1, vmax=1)
    plt.scatter(t_r, x_r, c='r', marker='.', alpha=0.1)
    plt.xlabel('$t$')
    plt.ylabel('$x$')

    plt.title('Positions of collocation points and boundary data');
    # creating image
    # in project pdf
    plt.savefig('collocation_points.pdf', bbox_inches='tight', dpi=300)
    # in project Image
    image_file_path = 'collocation_points.png'
    plt.savefig(image_file_path, bbox_inches='tight', dpi=300)
    # drive upload
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    file_name = 'collocation_points.png'
    file_link = upload_image_to_drive(buffer.read(),file_name)
    response_data['collocation_points'] = file_link
    buffer.close()
    layers = requestBody.get('layers')
    num_neurons_per_layer=20
    response_data['num_of_layers'] = layers
    response_data['num_neurons_per_layer'] = num_neurons_per_layer
    #4th cell
    def init_model(num_hidden_layers=layers, num_neurons_per_layer=num_neurons_per_layer):
    # Initialize a feedforward neural network
        model = tf.keras.Sequential()

        # Input is two-dimensional (time + one spatial dimension)
        model.add(tf.keras.Input(shape=(2,)))

        # Introduce a scaling layer to map input to [lb, ub]
        scaling_layer = tf.keras.layers.Lambda(
                    lambda x: 2.0*(x - lb)/(ub - lb) - 1.0)
        model.add(scaling_layer)

        # Append hidden layers
        for _ in range(num_hidden_layers):
            model.add(tf.keras.layers.Dense(num_neurons_per_layer,
                activation=tf.keras.activations.get('tanh'),
                kernel_initializer='glorot_normal'))

        # Output is one-dimensional
        model.add(tf.keras.layers.Dense(1))

        return model

    #5th Cell
    def get_r(model, X_r):

        # A tf.GradientTape is used to compute derivatives in TensorFlow
        with tf.GradientTape(persistent=True) as tape:
            # Split t and x to compute partial derivatives
            t, x = X_r[:, 0:1], X_r[:,1:2]

            # Variables t and x are watched during tape
            # to compute derivatives u_t and u_x
            tape.watch(t)
            tape.watch(x)

            # Determine residual
            u = model(tf.stack([t[:,0], x[:,0]], axis=1))

            # Compute gradient u_x within the GradientTape
            # since we need second derivatives
            u_x = tape.gradient(u, x)

        u_t = tape.gradient(u, t)
        u_xx = tape.gradient(u_x, x)

        del tape

        return fun_r(t, x, u, u_t, u_x, u_xx)

    #6th Cell
    def compute_loss(model, X_r, X_data, u_data):

        # Compute phi^r
        r = get_r(model, X_r)
        phi_r = tf.reduce_mean(tf.square(r))

        # Initialize loss
        loss = phi_r

        # Add phi^0 and phi^b to the loss
        for i in range(len(X_data)):
            u_pred = model(X_data[i])
            loss += tf.reduce_mean(tf.square(u_data[i] - u_pred))

        return loss
    
    #7th Cell
    def get_grad(model, X_r, X_data, u_data,trainable_variables):

        with tf.GradientTape(persistent=True) as tape:
            # This tape is for derivatives with
            # respect to trainable variables
            # Use the converted list in tape.watch()
            tape.watch(trainable_variables)
            loss = compute_loss(model, X_r, X_data, u_data)

        g = tape.gradient(loss, model.trainable_variables)
        del tape

        return loss, g

    #8th Cell
    # Initialize model aka u_\theta
    model = init_model()

    # We choose a piecewise decay of the learning rate, i.e., the
    # step size in the gradient descent type algorithm
    # the first 1000 steps use a learning rate of 0.01
    # from 1000 - 3000: learning rate = 0.001
    # from 3000 onwards: learning rate = 0.0005

    lr = tf.keras.optimizers.schedules.PiecewiseConstantDecay([1000,2000],[1e-2,1e-3,5e-4])

    # Choose the optimizer
    optim = tf.keras.optimizers.Adam(learning_rate=lr)

    #9th Cell
    from time import time

    # Define one training step as a TensorFlow function to increase speed of training
    @tf.function
    def train_step():
        # Compute current loss and gradient w.r.t. parameters
        trained_variables = [tf.convert_to_tensor(var) for var in model.trainable_variables]

        loss, grad_theta = get_grad(model, X_r, X_data, u_data,trained_variables)

        # Perform gradient descent step
        optim.apply_gradients(zip(grad_theta, model.trainable_variables))

        return loss

    # Number of training epochs
    N = 200
    hist = []
    # Start timer
    t0 = time()

    for i in range(N+1):

        loss = train_step()

        # Append current loss to hist
        hist.append(loss.numpy())

        # Output current loss after 50 iterates
        if i%50 == 0:
            print('It {:05d}: loss = {:10.8e}'.format(i,loss))

    # Print computation time
    response_data['training_data']['computation_time'] = format(time()-t0)
    print('\nComputation time: {} seconds'.format(time()-t0))

    #11th Cell
    from mpl_toolkits.mplot3d import Axes3D

    # Set up meshgrid
    N = 600
    tspace = np.linspace(lb[0], ub[0], N + 1)
    xspace = np.linspace(lb[1], ub[1], N + 1)
    T, X = np.meshgrid(tspace, xspace)
    Xgrid = np.vstack([T.flatten(),X.flatten()]).T

    # Determine predictions of u(t, x)
    upred = model(tf.cast(Xgrid,DTYPE))

    # Reshape upred
    U = upred.numpy().reshape(N+1,N+1)

    # Surface plot of solution u(t,x)
    fig = plt.figure(figsize=(9,6))
    ax = fig.add_subplot(111, projection='3d')
    ax.plot_surface(T, X, U, cmap='viridis');
    ax.view_init(35,35)
    ax.set_xlabel('$t$')
    ax.set_ylabel('$x$')
    ax.set_zlabel('$u_\\theta(t,x)$')
    ax.set_title('Solution of Burgers equation');
    #plt.savefig('Burgers_Solution.pdf', bbox_inches='tight', dpi=300);
    image_file_path = 'solution_of_burgers.png'
    plt.savefig(image_file_path, bbox_inches='tight', dpi=300)
    # drive upload
    buffer = io.BytesIO()
    plt.plot([1, 2, 3, 4], [1, 4, 9, 16])
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    file_name = 'solution_of_burgers.png'
    file_link = upload_image_to_drive(buffer.read(),file_name)
    response_data['solution_of_burgers']['image'] = file_link
    buffer.close()

    # 12th Cell
    fig = plt.figure(figsize=(9,6))
    ax = fig.add_subplot(111)
    ax.semilogy(range(len(hist)), hist,'k-')
    ax.set_xlabel('$n_{epoch}$')
    ax.set_ylabel('$\\phi_{n_{epoch}}$');



# Create a new buffer for the next image
    buffer = io.BytesIO()    
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    file_name_loss = 'solution_of_burgers_loss.png'
    file_link_loss = upload_image_to_drive(buffer.read(),file_name)
    response_data['solution_of_burgers']['loss']=file_link_loss
    # 13th Cell
    # Define model architecture
    class PINN_NeuralNet(tf.keras.Model):
        """ Set basic architecture of the PINN model."""

        def __init__(self, lb, ub,
                output_dim=1,
                num_hidden_layers=8,
                num_neurons_per_layer=num_neurons_per_layer,
                activation='tanh',
                kernel_initializer='glorot_normal',
                **kwargs):
            super().__init__(**kwargs)

            self.num_hidden_layers = num_hidden_layers
            self.output_dim = output_dim
            self.lb = lb
            self.ub = ub

            # Define NN architecture
            self.scale = tf.keras.layers.Lambda(
                lambda x: 2.0*(x - lb)/(ub - lb) - 1.0)
            self.hidden = [tf.keras.layers.Dense(num_neurons_per_layer,
                                activation=tf.keras.activations.get(activation),
                                kernel_initializer=kernel_initializer)
                            for _ in range(self.num_hidden_layers)]
            self.out = tf.keras.layers.Dense(output_dim)

        def call(self, X):
            """Forward-pass through neural network."""
            Z = self.scale(X)
            for i in range(self.num_hidden_layers):
                Z = self.hidden[i](Z)
            return self.out(Z)
    # 14th Cell
    import scipy.optimize

    class PINNSolver():
        def __init__(self, model, X_r):
            self.model = model

            # Store collocation points
            self.t = X_r[:,0:1]
            self.x = X_r[:,1:2]

            # Initialize history of losses and global iteration counter
            self.hist = []
            self.iter = 0

        def get_r(self):

            with tf.GradientTape(persistent=True) as tape:
                # Watch variables representing t and x during this GradientTape
                tape.watch(self.t)
                tape.watch(self.x)

                # Compute current values u(t,x)
                u = self.model(tf.stack([self.t[:,0], self.x[:,0]], axis=1))

                u_x = tape.gradient(u, self.x)

            u_t = tape.gradient(u, self.t)
            u_xx = tape.gradient(u_x, self.x)

            del tape

            return self.fun_r(self.t, self.x, u, u_t, u_x, u_xx)

        def loss_fn(self, X, u):

            # Compute phi_r
            r = self.get_r()
            phi_r = tf.reduce_mean(tf.square(r))

            # Initialize loss
            loss = phi_r

            # Add phi_0 and phi_b to the loss
            for i in range(len(X)):
                u_pred = self.model(X[i])
                loss += tf.reduce_mean(tf.square(u[i] - u_pred))

            return loss

        def get_grad(self, X, u,trained_X, trained_u):
            with tf.GradientTape(persistent=True) as tape:
                # This tape is for derivatives with
                # respect to trainable variables
                tape.watch(trained_X)
                tape.watch(trained_u)
                # tape.watch(self.model.trainable_variables)
                loss = self.loss_fn(X, u)

            g = tape.gradient(loss, self.model.trainable_variables)
            del tape

            return loss, g

        def fun_r(self, t, x, u, u_t, u_x, u_xx):
            """Residual of the PDE"""
            return u_t + u * u_x - viscosity * u_xx

        def solve_with_TFoptimizer(self, optimizer, X, u, N=500):
            """This method performs a gradient descent type optimization."""

            @tf.function
            def train_step():
                # print('Training step')
                # print(X,'X')
                # print(u,'u')
                trained_X = [tf.convert_to_tensor(var) for var in X]
                trained_u = [tf.convert_to_tensor(var) for var in u]
                loss, grad_theta = self.get_grad(X,u,trained_X, trained_u)

                # Perform gradient descent step
                optimizer.apply_gradients(zip(grad_theta, self.model.trainable_variables))
                return loss

            for i in range(N):

                loss = train_step()

                self.current_loss = loss.numpy()
                self.callback()

        def solve_with_ScipyOptimizer(self, X, u, method='L-BFGS-B', **kwargs):
            """This method provides an interface to solve the learning problem
            using a routine from scipy.optimize.minimize.
            (Tensorflow 1.xx had an interface implemented, which is not longer
            supported in Tensorflow 2.xx.)
            Type conversion is necessary since scipy-routines are written in Fortran
            which requires 64-bit floats instead of 32-bit floats."""

            def get_weight_tensor():
                """Function to return current variables of the model
                as 1d tensor as well as corresponding shapes as lists."""

                weight_list = []
                shape_list = []

                # Loop over all variables, i.e. weight matrices, bias vectors and unknown parameters
                for v in self.model.variables:
                    shape_list.append(v.shape)
                    weight_list.extend(v.numpy().flatten())

                weight_list = tf.convert_to_tensor(weight_list)
                return weight_list, shape_list

            x0, shape_list = get_weight_tensor()

            def set_weight_tensor(weight_list):
                """Function which sets list of weights
                to variables in the model."""
                idx = 0
                for v in self.model.variables:
                    vs = v.shape

                    # Weight matrices
                    if len(vs) == 2:
                        sw = vs[0]*vs[1]
                        new_val = tf.reshape(weight_list[idx:idx+sw],(vs[0],vs[1]))
                        idx += sw

                    # Bias vectors
                    elif len(vs) == 1:
                        new_val = weight_list[idx:idx+vs[0]]
                        idx += vs[0]

                    # Variables (in case of parameter identification setting)
                    elif len(vs) == 0:
                        new_val = weight_list[idx]
                        idx += 1

                    # Assign variables (Casting necessary since scipy requires float64 type)
                    v.assign(tf.cast(new_val, DTYPE))

            def get_loss_and_grad(w):
                """Function that provides current loss and gradient
                w.r.t the trainable variables as vector. This is mandatory
                for the LBFGS minimizer from scipy."""

                # Update weights in model
                set_weight_tensor(w)
                # Determine value of \phi and gradient w.r.t. \theta at w
                loss, grad = self.get_grad(X, u)

                # Store current loss for callback function
                loss = loss.numpy().astype(np.float64)
                self.current_loss = loss

                # Flatten gradient
                grad_flat = []
                for g in grad:
                    grad_flat.extend(g.numpy().flatten())

                # Gradient list to array
                grad_flat = np.array(grad_flat,dtype=np.float64)

                # Return value and gradient of \phi as tuple
                return loss, grad_flat

            # Define bounds for parameters
            num_params = len(x0)
            bounds = [(None, None)] * num_params  # Initialize with no bounds

            # Update bounds for parameters if needed
            # Example: bounds for parameters 0 to n are (lb, ub)
            # bounds[0:n] = [(lb, ub)] * n

            # Call scipy optimizer
            
            return scipy.optimize.minimize(fun=get_loss_and_grad,x0=x0,jac=True,method=method,bounds=bounds,callback=self.callback,**kwargs)

        def callback(self, xr=None):
            if self.iter % 50 == 0:
                print('It {:05d}: loss = {:10.8e}'.format(self.iter,self.current_loss))
            self.hist.append(self.current_loss)
            self.iter+=1


        def plot_solution(self, **kwargs):
            N = 600
            tspace = np.linspace(self.model.lb[0], self.model.ub[0], N+1)
            xspace = np.linspace(self.model.lb[1], self.model.ub[1], N+1)
            T, X = np.meshgrid(tspace, xspace)
            Xgrid = np.vstack([T.flatten(),X.flatten()]).T
            upred = self.model(tf.cast(Xgrid,DTYPE))
            U = upred.numpy().reshape(N+1,N+1)
            fig = plt.figure(figsize=(9,6))
            ax = fig.add_subplot(111, projection='3d')
            ax.plot_surface(T, X, U, cmap='viridis', **kwargs)
            ax.set_xlabel('$t$')
            ax.set_ylabel('$x$')
            ax.set_zlabel('$u_\\theta(t,x)$')
            ax.view_init(35,35)
            return ax

        def plot_loss_history(self, ax=None):
            if not ax:
                fig = plt.figure(figsize=(7,5))
                ax = fig.add_subplot(111)
            ax.semilogy(range(len(self.hist)), self.hist,'k-')
            ax.set_xlabel('$n_{epoch}$')
            ax.set_ylabel('$\\phi^{n_{epoch}}$')
            return ax
    
    # 15th Cell
    # Initialize model
    model = PINN_NeuralNet(lb, ub)
    model.build(input_shape=(None,2))

    # Initilize PINN solver
    solver = PINNSolver(model, X_r)

    # Decide which optimizer should be used
    #mode = 'TFoptimizer'
    mode = 'ScipyOptimizer'

    # Start timer
    t0 = time()

    # Print computation time
    response_data['spicy_optimizer']['computation_time'] = format(time()-t0)
    print('\nComputation time: {} seconds'.format(time()-t0))

    # 16th Cell
    solver.plot_solution();
    solver.plot_loss_history();

    # 17th Cell
    N_0 = 50
    N_b = 50
    N_r = 10000

    # Specify boundaries
    lb = tf.constant([0., -1.], dtype=DTYPE)
    ub = tf.constant([1., 1.], dtype=DTYPE)

    def Eikonal_u_0(x):
        n = x.shape[0]
        return tf.zeros((n,1), dtype=DTYPE)

    def Eikonal_u_b(t, x):
        n = x.shape[0]
        return tf.zeros((n,1), dtype=DTYPE)

    # 18th Cell
    tf.random.set_seed(0)

    # Final time data
    t_0 = tf.ones((N_0,1), dtype=DTYPE) * ub[0]
    x_0 = tf.random.uniform((N_0,1), lb[1], ub[1], dtype=DTYPE)
    X_0 = tf.concat([t_0, x_0], axis=1)
    u_0 = Eikonal_u_0(x_0)

    # Boundary data
    t_b = tf.random.uniform((N_b,1), lb[0], ub[0], dtype=DTYPE)
    x_b = lb[1] + (ub[1] - lb[1]) * tf.keras.backend.random_bernoulli((N_b,1), 0.5, dtype=DTYPE)
    X_b = tf.concat([t_b, x_b], axis=1)
    u_b = Eikonal_u_b(t_b, x_b)

    # Collocation points
    t_r = tf.random.uniform((N_r,1), lb[0], ub[0], dtype=DTYPE)
    x_r = tf.random.uniform((N_r,1), lb[1], ub[1], dtype=DTYPE)
    X_r = tf.concat([t_r, x_r], axis=1)

    # Collect boundary and inital data in lists
    X_data = [X_0,X_b]
    u_data = [u_0,u_b]

    #19th Cell
    class EikonalPINNSolver(PINNSolver):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def fun_r(self, t, x, u, u_t, u_x, u_xx):
            """Residual of the PDE"""
            return -u_t + tf.abs(u_x) - 1.

        def get_r(self):
            """We update get_r since the Eikonal equation is a first-order equation.
            Therefore, it is not necessary to compute second derivatives."""

            with tf.GradientTape(persistent=True) as tape:
                # Watch variables representing t and x during this GradientTape
                tape.watch(self.t)
                tape.watch(self.x)

                # Compute current values u(t,x)
                u = self.model(tf.stack([self.t[:,0], self.x[:,0]], axis=1))

            u_x = tape.gradient(u, self.x)

            u_t = tape.gradient(u, self.t)

            del tape

            return self.fun_r(self.t, self.x, u, u_t, u_x, None)
    
    # 20th Cell
    # Initialize model
    model = PINN_NeuralNet(lb, ub, num_hidden_layers=2,
                        activation=tf.keras.layers.LeakyReLU(alpha=0.1),
                                        kernel_initializer='he_normal')
    model.build(input_shape=(None,2))

    # Initilize PINN solver
    eikonalSolver = EikonalPINNSolver(model, X_r)
    # 21st Cell
    # Choose step sizes aka learning rate
    lr = tf.keras.optimizers.schedules.PiecewiseConstantDecay([1000,2000],[1e-1,1e-2,1e-3])

    # Solve with Adam optimizer
    optim = tf.keras.optimizers.Adam(learning_rate=lr)

    # Start timer
    t0 = time()
    eikonalSolver.solve_with_TFoptimizer(optim, X_data, u_data, N=500)

    # Print computation time
    
    response_data['eikonal_solver']['computation_time'] = format(time()-t0)
    print('\nComputation time: {} seconds'.format(time()-t0))

    # 22nd Cell
    eikonalSolver.plot_solution();
    #plt.savefig('Eikonal_Solution.pdf', bbox_inches='tight', dpi=300)
    eikonalSolver.plot_loss_history();

    # 23rd Cell
    lambd_star = 3.

    def u_expl(t, x, lambd_star):
        """Explicit solution of the parametric Eikonal equation."""
        y = 1./lambd_star
        return y * tf.math.minimum(1-t, 1-tf.abs(x))

    # 24th Cell
    N_d = 500
    noise = 0.0

    # Draw points with measurements randomly
    t_d = tf.random.uniform((N_d,1), lb[0], ub[0], dtype=DTYPE)
    x_d = tf.random.uniform((N_d,1), lb[1], ub[1], dtype=DTYPE)
    X_d = tf.concat([t_d, x_d], axis=1)
    u_d = u_expl(t_d, x_d, lambd_star)
    u_d += noise * tf.random.normal(u_d.shape, dtype=DTYPE)

    # Copy original data
    X_param = X_data
    u_param = u_data

    # 25th Cell
    X_param.append(X_d)
    u_param.append(u_d)
    # 26th Cell
    class PINNIdentificationNet(PINN_NeuralNet):
        def __init__(self, *args, **kwargs):

            # Call init of base class
            super().__init__(*args,**kwargs)

            # Initialize variable for lambda
            self.lambd = tf.Variable(1.0, trainable=True, dtype=DTYPE)
            self.lambd_list = []

    # 27th Cell
    class EikonalPINNIdentification(EikonalPINNSolver):

        def fun_r(self, t, x, u, u_t, u_x, u_xx):
            """Residual of the PDE"""
            return -u_t + tf.abs(u_x) - 1./self.model.lambd

        def callback(self, xr=None):
            lambd = self.model.lambd.numpy()
            self.model.lambd_list.append(lambd)

            if self.iter % 50 == 0:
                print('It {:05d}: loss = {:10.8e} lambda = {:10.8e}'.format(self.iter, self.current_loss, lambd))

            self.hist.append(self.current_loss)
            self.iter += 1

        def plot_loss_and_param(self, axs=None):
            if axs:
                ax1, ax2 = axs
                self.plot_loss_history(ax1)
            else:
                ax1 = self.plot_loss_history()
                ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis

            color = 'tab:blue'
            ax2.tick_params(axis='y', labelcolor=color)
            ax2.plot(range(len(self.hist)), self.model.lambd_list,'-',color=color)
            ax2.set_ylabel('$\\lambda^{n_{epoch}}$', color=color)
            return (ax1,ax2)
    # 28th Cell
    # Initialize model
    model = PINNIdentificationNet(lb, ub, num_hidden_layers=2,
                                            activation=tf.keras.layers.LeakyReLU(alpha=0.1),
                                            kernel_initializer='he_normal')

    model.build(input_shape=(None,2))

    # Initilize solver
    eikonalIdentification = EikonalPINNIdentification(model, X_r)

    # Choose step sizes aka learning rate
    lr = tf.keras.optimizers.schedules.PiecewiseConstantDecay([3000,7000],[1e-1,1e-2,1e-3])

    # Solve with Adam optimizer
    optim = tf.keras.optimizers.Adam(learning_rate=lr)

    # Start timer
    t0 = time()
    eikonalIdentification.solve_with_TFoptimizer(optim, X_param, u_param, N=500)

    # Print computation time
    response_data['eikonal_identification']['computation_time'] = format(time()-t0)
    print('\nComputation time: {} seconds'.format(time()-t0))

    # 29th Cell
    ax = eikonalIdentification.plot_solution()
    #plt.savefig('Eikonal_PI_Solution.pdf', bbox_inches='tight', dpi=300)
    axs = eikonalIdentification.plot_loss_and_param()
    #plt.savefig('Eikonal_PI_LossEvolution.pdf', bbox_inches='tight', dpi=300)

    # 30th Cell
    lambda_rel_error = np.abs((eikonalIdentification.model.lambd.numpy()-lambd_star)/lambd_star)
    response_data['lambda_rel_error']=lambda_rel_error
    print('Relative error of lambda ', lambda_rel_error)

    # 31st Cell
    lambd_hist = []
    loss_hist = []
    for i in range(1):
        print('{:s}\nStart of iteration {:d}\n{:s}'.format(50*'-',i,50*'-'))
        # Initialize model
        model = PINNIdentificationNet(lb, ub, num_hidden_layers=2,
                                            activation=tf.keras.layers.LeakyReLU(alpha=0.1),
                                            kernel_initializer='he_normal')

        model.build(input_shape=(None,2))

        # Initilize solver
        eikonalIdentification = EikonalPINNIdentification(model, X_r)

        # Choose step sizes aka learning rate
        lr = tf.keras.optimizers.schedules.PiecewiseConstantDecay([1000,2000],[1e-1,1e-2,1e-3])
        N=500

        # Solve with Adam optimizer
        optim = tf.keras.optimizers.Adam(learning_rate=lr)

        eikonalIdentification.solve_with_TFoptimizer(optim, X_param, u_param, N=N)

        # Store evolution of lambdas
        lambd_hist.append(model.lambd_list)

        # Store evolution of losses
        loss_hist.append(eikonalIdentification.hist)
    # 32nd Cell
    print('  i     Mean of lambda   Std. of lambda')
    for i in range(len(lambd_hist)):
        xi = np.array([ x[i] for x in lambd_hist])
        response_data['lambda_computation']={"mean_of_lambda":str(xi.mean()),"std_of_lambda":str(xi.std())}
        print('{:05d}     {:6.4e}       {:6.4e}'.format(i, xi.mean(), xi.std()))
    # 33rd Cell
    fig = plt.figure()
    ax = fig.add_subplot(111)
    color = 'tab:blue'

    Lambd = np.stack(lambd_hist)
    lmean = Lambd.mean(axis=0)
    lstd = Lambd.std(axis=0)
    Lambd_RelError = np.abs((Lambd-lambd_star)/lambd_star)
    lrange=range(len(lmean))

    for i in range(len(lambd_hist)):
        ax.plot(lrange, lambd_hist[i],'-',color='black', alpha=0.5)
    ax.plot(lrange, lmean,'-',color=color)
    ax.plot(lrange, lambd_star*np.ones_like(lmean),'--',color=color)
    ax.fill_between(lrange,lmean-lstd,lmean+lstd, alpha=0.2)
    ax.set_ylabel('$\\lambda^{n_{epoch}}$')
    ax.set_xlabel('$n_{epoch}$')
    ax.set_ylim([2.8,3.2])
    #plt.savefig('Eikonal_PI_Evolution.pdf', bbox_inches='tight', dpi=300)

    # 34th Cell
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.semilogy(lrange,Lambd_RelError.mean(axis=0))
    ax.fill_between(lrange,Lambd_RelError.mean(axis=0)-Lambd_RelError.std(axis=0),
                    Lambd_RelError.mean(axis=0)+Lambd_RelError.std(axis=0), alpha=0.2)
    ax.set_xlabel('$n_{epoch}$')
    ax.set_ylabel('$e_{\\lambda}^{rel}$')
    ax.set_title('Mean relative error of $\\lambda$');
    return response_data