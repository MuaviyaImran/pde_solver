# pip install virtualenv
#virtualenv venv

#for mac & unix -->source venv/bin/activate
#for windows --> venv\Scripts\activate


#pip install spicy flask tensorflow jsonify numpy matplotlib tensorflow-probability
#pip install --upgrade google-api-python-client google-auth-httplib2 google-auth-oauthlib

from flask import Flask
from flask import jsonify
from flask import request
from helper_functions import run_code
app = Flask(__name__)
import tensorflow_probability as tfp
from flask_cors import CORS
CORS(app)
@app.route('/run_code', methods=['POST'])

def index():
    try:
        # Get data from request body
        data = request.get_json()  
        requestBody = {
            'xmax': data.get('xmax'),
            'xmin': data.get('xmin'),
            'tmax': data.get('tmax'),
            'tmin': data.get('tmin'),
            'function': data.get('function'),
        }
        response_data=run_code(requestBody)
        return jsonify({'data':response_data,'status':'ok','message': 'Prediction executed successfully'})
        return jsonify({'data':"response_data",})
    except ValueError as e:
    # Handle the case where the input cannot be converted to an integer
      print("Please enter a valid integer.", e)
      return jsonify({'message': 'Please enter a valid integer.'})
    except ZeroDivisionError:
        # Handle the case where division by zero occurs
        print("Cannot divide by zero.")
        return jsonify({'message': 'Cannot divide by zero.'})
    except Exception as e:
        # Handle any other exceptions that may occur
        print("An error occurred:", e)
        return jsonify({'message': 'An error occurred:'})
    else:
        # Code to execute if no exceptions were raised
        print("No exceptions were raised.")
        return jsonify({'message': 'No exceptions were raised.'})
    finally:
        # Code to execute whether an exception occurred or not
        print("This will always execute.")

if __name__ == '__main__':
    app.run(debug=True)
