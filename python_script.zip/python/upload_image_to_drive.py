from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseUpload
from googleapiclient.errors import HttpError
import io
import os
import pdb
import tempfile
# Authenticate using a service account key file
credentials = service_account.Credentials.from_service_account_file(
    './credentials.json',
    scopes=['https://www.googleapis.com/auth/drive']
)

# Create a Google Drive API service
service = build('drive', 'v3', credentials=credentials)

def upload_image_to_drive(image_data,file_name):
    file_metadata = {
        'name': file_name,  # Specify the name of the file
        'mimeType': 'image/png'
    }

    media = MediaIoBaseUpload(io.BytesIO(image_data), mimetype='image/png')
    
    # Set permissions for the file to be accessible to anyone with the link
    permission = {'type': 'anyone', 'role': 'reader'}

    try:
        file = service.files().create(body=file_metadata, media_body=media, fields='id').execute()
        file_id = file.get('id')
        service.permissions().create(fileId=file_id, body=permission).execute()

        return f"https://drive.google.com/uc?id={file_id}"
    except HttpError as e:
        print(f"An error occurred: {e}")
        return None
    